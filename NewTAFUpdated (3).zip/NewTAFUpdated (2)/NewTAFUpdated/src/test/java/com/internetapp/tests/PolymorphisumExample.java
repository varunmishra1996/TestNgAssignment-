package com.internetapp.tests;

public class PolymorphisumExample {
	
	
	void display(String name) {
		System.out.println("name is: "+name);
	}
	
	void display(int a,int b) {
		System.out.println("the value of a and b is: "+a+b);
	}
 
	public static void main(String[] args) {
		new PolymorphisumExample().display("maveric-systems");
		new PolymorphisumExample().display(2,3);
	}
}
