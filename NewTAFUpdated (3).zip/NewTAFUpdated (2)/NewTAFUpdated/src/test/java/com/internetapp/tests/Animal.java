package com.internetapp.tests;

public class Animal {

}
