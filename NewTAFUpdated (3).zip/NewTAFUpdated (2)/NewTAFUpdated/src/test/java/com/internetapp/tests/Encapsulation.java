package com.internetapp.tests;


class Employee{
	private String empName;
	private int empId;
	private String companyName;
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	
	
}

public class Encapsulation {
	public static void main(String[] args) {
	       
        Employee emp=new Employee();
        emp.setEmpName("Anitha");
        emp.setEmpId(4161);
        emp.setCompanyName("Maveric");
       
        System.out.println("The employee name is " +emp.getEmpName() +" And ID is "+emp.getEmpId()+ " And Company Name is " +emp.getCompanyName());
       
   }

	
	
}
